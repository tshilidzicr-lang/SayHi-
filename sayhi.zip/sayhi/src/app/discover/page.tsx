'use client'

import { useEffect, useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import { useAuth } from '@/hooks/useAuth'
import { User } from '@/types'
import SwipeCard from '@/components/swipe/SwipeCard'
import MatchModal from '@/components/swipe/MatchModal'
import BottomNav from '@/components/ui/BottomNav'
import { X, Heart, Zap, MapPin } from 'lucide-react'
import toast from 'react-hot-toast'

export default function DiscoverPage() {
  const { supabaseUser, profile, loading } = useAuth()
  const router = useRouter()
  const supabase = createClient()

  const [candidates, setCandidates] = useState<User[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [fetchingUsers, setFetchingUsers] = useState(true)
  const [matchModal, setMatchModal] = useState<{ matchId: string; matchedUser: User } | null>(null)
  const [locationEnabled, setLocationEnabled] = useState(false)
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [superLiking, setSuperLiking] = useState(false)

  useEffect(() => {
    if (!loading && !supabaseUser) router.replace('/auth')
    if (!loading && supabaseUser && !profile?.name) router.replace('/profile?setup=true')
  }, [supabaseUser, profile, loading, router])

  // Get user location
  useEffect(() => {
    if (!navigator.geolocation) return
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude }
        setUserLocation(loc)
        setLocationEnabled(true)
        // Update user location in DB
        if (supabaseUser) {
          await supabase
            .from('users')
            .update({ location: loc })
            .eq('id', supabaseUser.id)
        }
      },
      () => setLocationEnabled(false)
    )
  }, [supabaseUser])

  const fetchCandidates = useCallback(async () => {
    if (!supabaseUser) return
    setFetchingUsers(true)
    try {
      // Get already liked/passed users
      const { data: liked } = await supabase
        .from('likes')
        .select('to_user_id')
        .eq('from_user_id', supabaseUser.id)

      const excludeIds = [supabaseUser.id, ...(liked?.map((l) => l.to_user_id) || [])]

      const { data: users, error } = await supabase
        .from('users')
        .select('*')
        .not('id', 'in', `(${excludeIds.join(',')})`)
        .not('name', 'is', null)
        .limit(20)

      if (error) throw error
      setCandidates(users || [])
      setCurrentIndex(0)
    } catch (err) {
      console.error(err)
    } finally {
      setFetchingUsers(false)
    }
  }, [supabaseUser])

  useEffect(() => {
    if (supabaseUser && profile?.name) fetchCandidates()
  }, [supabaseUser, profile, fetchCandidates])

  const handleLike = async (targetUser: User) => {
    if (!supabaseUser || !profile) return
    try {
      // Record like
      await supabase.from('likes').insert({
        from_user_id: supabaseUser.id,
        to_user_id: targetUser.id,
      })

      // Check if mutual like
      const { data: mutualLike } = await supabase
        .from('likes')
        .select('id')
        .eq('from_user_id', targetUser.id)
        .eq('to_user_id', supabaseUser.id)
        .maybeSingle()

      if (mutualLike) {
        // Create match
        const { data: match } = await supabase
          .from('matches')
          .insert({
            user1_id: supabaseUser.id,
            user2_id: targetUser.id,
          })
          .select()
          .single()

        if (match) {
          setMatchModal({ matchId: match.id, matchedUser: targetUser })
        }
      }

      nextCard()
    } catch (err) {
      console.error(err)
      toast.error('Something went wrong')
    }
  }

  const handlePass = () => {
    nextCard()
  }

  const nextCard = () => {
    setCurrentIndex((prev) => prev + 1)
  }

  const currentUser = candidates[currentIndex]
  const nextUser = candidates[currentIndex + 1]

  return (
    <div className="h-screen flex flex-col bg-coal-900 overflow-hidden">
      {/* Header */}
      <div className="flex-none flex items-center justify-between px-5 pt-14 pb-4">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🔥</span>
          <span
            className="text-xl font-black ember-text"
            style={{ fontFamily: "'Space Mono', monospace" }}
          >
            SayHi
          </span>
        </div>
        <div className="flex items-center gap-2">
          {locationEnabled && (
            <div className="flex items-center gap-1 text-green-400 text-xs bg-green-400/10 px-2 py-1 rounded-full">
              <MapPin className="w-3 h-3" />
              <span>Near you</span>
            </div>
          )}
        </div>
      </div>

      {/* Card stack */}
      <div className="flex-1 relative px-4 pb-4 overflow-hidden">
        {fetchingUsers ? (
          <div className="h-full flex flex-col items-center justify-center gap-4">
            <div className="text-4xl animate-pulse">🔥</div>
            <p className="text-coal-400 text-sm">Finding people near you...</p>
          </div>
        ) : !currentUser ? (
          <div className="h-full flex flex-col items-center justify-center gap-4 text-center px-8">
            <div className="text-6xl mb-2">😮‍💨</div>
            <h3 className="text-white text-xl font-bold">You've seen everyone!</h3>
            <p className="text-coal-400 text-sm leading-relaxed">
              Check back later as more people join SayHi 🔥
            </p>
            <button
              onClick={fetchCandidates}
              className="btn-ember px-6 py-3 rounded-xl text-white font-semibold text-sm mt-2"
            >
              Refresh
            </button>
          </div>
        ) : (
          <div className="relative h-full">
            {/* Next card (behind) */}
            {nextUser && (
              <div
                className="absolute inset-0 rounded-3xl overflow-hidden"
                style={{
                  transform: 'scale(0.94) translateY(16px)',
                  zIndex: 5,
                }}
              >
                <SwipeCard
                  key={`next-${nextUser.id}`}
                  user={nextUser}
                  onLike={() => {}}
                  onPass={() => {}}
                  isTop={false}
                />
              </div>
            )}
            {/* Top card */}
            <SwipeCard
              key={`top-${currentUser.id}`}
              user={currentUser}
              onLike={() => handleLike(currentUser)}
              onPass={handlePass}
              isTop={true}
            />
          </div>
        )}
      </div>

      {/* Action buttons */}
      {currentUser && !fetchingUsers && (
        <div className="flex-none flex items-center justify-center gap-5 pb-24 px-4">
          {/* Pass */}
          <button
            onClick={handlePass}
            className="w-16 h-16 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
            style={{
              background: 'rgba(255,255,255,0.06)',
              border: '2px solid rgba(255,255,255,0.1)',
              boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
            }}
          >
            <X className="w-7 h-7 text-white/60" strokeWidth={2.5} />
          </button>

          {/* Super like */}
          <button
            onClick={async () => {
              if (superLiking) return
              setSuperLiking(true)
              toast('⚡ Super Liked!', { icon: '⚡' })
              await handleLike(currentUser)
              setSuperLiking(false)
            }}
            className="w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
            style={{
              background: 'rgba(99, 179, 237, 0.1)',
              border: '2px solid rgba(99, 179, 237, 0.3)',
            }}
          >
            <Zap className="w-5 h-5 text-blue-300" fill="currentColor" />
          </button>

          {/* Like */}
          <button
            onClick={() => handleLike(currentUser)}
            className="w-16 h-16 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
            style={{
              background: 'linear-gradient(135deg, #ff6b50, #ff4d33)',
              boxShadow: '0 4px 24px rgba(255,77,51,0.5)',
            }}
          >
            <Heart className="w-7 h-7 text-white" fill="white" />
          </button>
        </div>
      )}

      {/* Match modal */}
      {matchModal && profile && (
        <MatchModal
          currentUser={profile}
          matchedUser={matchModal.matchedUser}
          matchId={matchModal.matchId}
          onClose={() => setMatchModal(null)}
        />
      )}

      <BottomNav />
    </div>
  )
}
