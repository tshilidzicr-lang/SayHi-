# SayHi 🔥

A Tinder-style "No Strings Attached" dating web app built with Next.js 14 + Supabase.

**Swipe. Match. Connect.**

---

## ✨ Features

- 🔐 **Auth** — Email/password + anonymous sign-in via Supabase Auth
- 👤 **Profile** — Name, bio, age, photo upload to Supabase Storage
- 💘 **Swipe UI** — Tinder-style drag cards with like/pass/super-like
- 🔥 **Matching** — Mutual like detection → instant match notification
- 💬 **Realtime Chat** — Supabase Realtime powered live messaging
- 📍 **Location** — Browser geolocation to show nearby users
- 📱 **Mobile-first** — Dark theme, smooth animations

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone <your-repo>
cd sayhi
npm install
```

### 2. Set up Supabase

1. Go to [supabase.com](https://supabase.com) → Create a new project
2. Go to **SQL Editor** → paste and run `supabase-schema.sql`
3. Go to **Settings → API** → copy your keys

### 3. Configure Environment

```bash
cp .env.example .env.local
```

Edit `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
```

### 4. Enable Anonymous Auth (optional)

Go to Supabase Dashboard → **Authentication → Providers → Anonymous** → Enable

### 5. Run

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 📦 Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

1. Push to GitHub
2. Import in Vercel
3. Add environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Deploy!

---

## 🗄️ Database Schema

```
users       → id, name, bio, age, photo_url, location, created_at
likes       → id, from_user_id, to_user_id, created_at
matches     → id, user1_id, user2_id, created_at
messages    → id, match_id, sender_id, text, created_at
```

Storage bucket: `profile-photos` (public)

---

## 🔧 Supabase Setup Checklist

- [ ] Create project on supabase.com
- [ ] Run `supabase-schema.sql` in SQL Editor
- [ ] Enable Anonymous Auth (Dashboard → Auth → Providers)
- [ ] Verify `profile-photos` storage bucket was created (Dashboard → Storage)
- [ ] Copy URL and anon key to `.env.local`
- [ ] Enable Realtime for `messages` table (Dashboard → Database → Replication)

---

## 🏗️ Tech Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 14 (App Router) |
| Styling | Tailwind CSS |
| Backend | Supabase (Auth + DB + Storage + Realtime) |
| Animations | CSS + Framer Motion |
| Icons | Lucide React |
| Notifications | React Hot Toast |

---

## 📁 Project Structure

```
src/
├── app/
│   ├── auth/          → Sign in / Sign up
│   ├── discover/      → Swipe cards
│   ├── matches/       → Match list
│   ├── chat/
│   │   └── [id]/      → Individual chat
│   └── profile/       → Profile setup & edit
├── components/
│   ├── swipe/         → SwipeCard, MatchModal
│   └── ui/            → BottomNav
├── hooks/
│   └── useAuth.tsx    → Auth context
├── lib/
│   ├── supabase.ts    → Browser client
│   └── supabase-server.ts → Server client
└── types/
    └── index.ts       → TypeScript types
```

---

## 🔒 Security

- Row Level Security (RLS) enabled on all tables
- Users can only read/write their own data
- Matches required before messaging
- Storage bucket policies restrict uploads to authenticated users

---

Built with ❤️ and 🔥
