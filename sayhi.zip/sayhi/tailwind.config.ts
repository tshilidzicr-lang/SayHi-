import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["'Clash Display'", "system-ui", "sans-serif"],
        body: ["'Satoshi'", "system-ui", "sans-serif"],
      },
      colors: {
        ember: {
          50: "#fff1f0",
          100: "#ffe4e0",
          200: "#ffccc5",
          300: "#ffa89b",
          400: "#ff7a65",
          500: "#ff4d33",
          600: "#ed2d0f",
          700: "#c8220c",
          800: "#a51f0f",
          900: "#881f14",
        },
        coal: {
          900: "#0a0a0b",
          800: "#111113",
          700: "#18181c",
          600: "#222228",
          500: "#2d2d36",
          400: "#3a3a46",
        },
      },
      animation: {
        "swipe-left": "swipeLeft 0.4s ease-in forwards",
        "swipe-right": "swipeRight 0.4s ease-in forwards",
        "card-enter": "cardEnter 0.3s ease-out",
        "pulse-glow": "pulseGlow 2s ease-in-out infinite",
      },
      keyframes: {
        swipeLeft: {
          "0%": { transform: "translateX(0) rotate(0deg)", opacity: "1" },
          "100%": { transform: "translateX(-150%) rotate(-30deg)", opacity: "0" },
        },
        swipeRight: {
          "0%": { transform: "translateX(0) rotate(0deg)", opacity: "1" },
          "100%": { transform: "translateX(150%) rotate(30deg)", opacity: "0" },
        },
        cardEnter: {
          "0%": { transform: "scale(0.9) translateY(20px)", opacity: "0" },
          "100%": { transform: "scale(1) translateY(0)", opacity: "1" },
        },
        pulseGlow: {
          "0%, 100%": { boxShadow: "0 0 20px rgba(255,77,51,0.3)" },
          "50%": { boxShadow: "0 0 40px rgba(255,77,51,0.7)" },
        },
      },
    },
  },
  plugins: [],
};
export default config;
